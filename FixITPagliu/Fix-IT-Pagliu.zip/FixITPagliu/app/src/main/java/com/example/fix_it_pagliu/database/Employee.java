package com.example.fix_it_pagliu.database;

import java.util.Date;

public class Employee extends User {
    public Employee(String fullname, String surname, String fiscalCode, String birthday, String email) {
        super(fullname, surname, fiscalCode, birthday, email);
    }
}
